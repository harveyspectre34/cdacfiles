select customer_name, city|| ' , ' ||state||' , '||country as address from customer;

select trim ('post gre sql');

select customer_id,customer_name,
substring(customer_id for 2) as cust_group
from customer
where substring(customer_id for 2) ='AB';

select customer_id,customer_name,
substring(customer_id from 4 for 5) as customer_num
from customer
where substring(customer_id for 2) ='AB';

select * from sales order by order_id;

select order_id,string_agg(product_id,',')
from sales
group by order_id
order by order_id; // important query

select * from product;
select customer_id from sales_2015
intersect 
select customer_id from customer_20_60;

select customer_id from sales_2015
except
select customer_id from customer_20_60 
order by customer_id;

select customer_id from sales_2015
union
select  customer_id from customer_20_60
order by customer_id;

select * from customer

select * from sales
where customer_id in 
(select customer_id from customer where age > 60);

select * from product;

SELECT a.product_id,a.product_name,a.category,b.quantity
FROM product as a
left join (select product_id,sum(quantity) as quantity from sales group by product_id) as b
on a.product_id = b.product_id
order by b.quantity desc;

select customer_id,order_line,(select customer_name from customer where customer.customer_id=sales.customer_id)
from sales
order by customer_id;





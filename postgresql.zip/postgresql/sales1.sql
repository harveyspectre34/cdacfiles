select * from sales1;
ALTER TABLE sales1 ADD COLUMN mositurizer INTEGER ;
ALTER TABLE sales1 DROP COLUMN unit_prize;
ALTER TABLE sales1 DROP COLUMN profit;
ALTER TABLE sales1 DROP COLUMN unit_price;
ALTER TABLE sales1 ADD COLUMN total_units INTEGER ;
ALTER TABLE sales1 ADD COLUMN total_profit INTEGER ;
ALTER TABLE sales1 RENAME COLUMN total_profit TO profit;
COPY sales1 FROM 'C:\Program Files\PostgreSQL\17\data\dataset\company-sales.csv'
DELIMITER ','
CSV HEADER;

select sum(profit) AS net_worth from sales1;
SELECT SUM(profit)from sales1 WHERE month_number = 3;
SELECT SUM(profit)
FROM sales1
WHERE month_number = 3;
create table custdata1(
invoice_no varchar,
customer_id varchar,
gender varchar,
age int,
category varchar,
quantity int,
price  varchar,
payment_method varchar,
invoice_date date,
shopping_mall varchar
);
SET DATESTYLE TO 'dmy';
COPY custdata1
FROM 'C:/Program Files/PostgreSQL/17/data/dataset/shopping_data.csv'
DELIMITER ','
CSV HEADER;

select * from custdata1; 
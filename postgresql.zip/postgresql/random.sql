select order_line,
sales,
ceil(sales),
floor(sales)
from sales;

/* a=10,b=50 */
select random(),random()*(50-10)+10,floor(random()*(50-10))+10;
select floor(random()*(50-10))+10;

select setseed(0.5);
select random();
select random();

select setseed(0.5);

select random();
select random();

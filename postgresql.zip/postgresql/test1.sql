select * from customer_table;
update customer_table set last_name = 'Kale',age=17 where cust_id =2;
select * from customer_table;
update customer_table set email_id = 'gee@xyz.com' where first_name='gee';
delete from customer_table where cust_id = 6;
select * from customer_table;
delete from customer_table where age > 30;
select * from customer_table;
WITH duplicates AS (
    SELECT 
        cust_id,
        ROW_NUMBER() OVER (PARTITION BY email_id ORDER BY cust_id) as row_num
    FROM customer_table
)
DELETE FROM customer_table
WHERE cust_id IN (
    SELECT cust_id FROM duplicates WHERE row_num > 1
);
select * from customer_table;
select customer_name,Length(customer_name) as characters_num
from customer
where age > 13;

select product_name,length(product_name) as length
from product
order by length desc;


select upper('start-tech academy');

select lower('start tech academy');
SELECT LENGTH(ship_mode) from sales where order_line=7973;

select customer_name,
country,
replace(country,'United States','US') as country_new
from customer;

select customer_name,
country,
replace(lower(country),'united states','US') as country_new
from customer;

select trim(leading ' ' from '    Start-tech Academy    ');
select trim(trailing  ' ' from '    Start-tech Academy    ');
select trim(both '  ' from '    Start-tech Academy    ','');
select rtrim('    Start-tech Academy    ',' ');
select ltrim( '    Start-tech Academy    ',' ');
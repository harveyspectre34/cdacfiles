create table customer1(
Index int,
Customer varchar primary key,
First_Name varchar,
Last_Name  varchar,
Company varchar,
City    varchar,
Country varchar,
Email  varchar
);



COPY customer1 FROM 'C:/Program Files/PostgreSQL/17/data/dataset/customers.csv' DELIMITER ','CSV HEADER;
select * from customer;
select * from customer where country in ('Canada','Netherlands');

select * from customer where index between 4 and 50;


select * from customer_order;
select customer_id,customer_name,state,order_num from customer_order;

select customer_id,customer_name,state,order_num,
row_number() over (partition by state order by order_num desc) as row_n,
rank()  over (partition by state order by order_num desc) as rank_n,
dense_rank() over (partition by state order by order_num desc) as d_rank_n
NTILE(5) over (partition by state order by order_num desc) as tile_n,
from customer_order;

SELECT * FROM(
SELECT customer_id,
       customer_name,
       state,
       order_num,
       ROW_NUMBER() OVER (PARTITION BY state ORDER BY order_num DESC) AS row_n,
       RANK() OVER (PARTITION BY state ORDER BY order_num DESC) AS rank_n,
       DENSE_RANK() OVER (PARTITION BY state ORDER BY order_num DESC) AS d_rank_n,
       NTILE(5) OVER (PARTITION BY state ORDER BY order_num DESC) AS tile_n
FROM customer_order) as a where a.tile_n=5;
create user starttech
with password 'academy';

grant select,update insert,delete on product to starttect;

revoke delete on product from starttech;

drop user starttech;

revoke all on product from starttech;

select * from pg_user;

select distinct usename from pg_stat_activity;

select distinct * from pg_stat_activity;

select * from customer
where customer_name like'jo%';

select * from customer
where customer_name like'%od%';

select * from customer
where customer_name ~*'^a+[a-z\s]+$';

select * from customer
where customer_name ~*'^(a|b|c|d)+[a-z\s]+$';

select * from customer
where customer_name ~*'^(a|b|c|d)[a-z]{3}\s[a-z]{4}$';

select * from users;

SELECT COUNT(*)
FROM customer
WHERE LENGTH(customer_name) = 5
  AND LENGTH(last_name) = 5
  AND last_name ~* '^[a-d]{1}[a-zA-Z]{4}$';

  SELECT COUNT(*)
FROM customer
WHERE customer_name ~* '^[a-d]{1}[a-zA-Z]{4} [a-zA-Z]{5}$';


SELECT COUNT(*)
FROM customer
WHERE postal_code ~ '[0-9]{5}';

SELECT COUNT(*)
FROM customer
WHERE TO_CHAR(postal_code) ~ '[0-9]{5}';

SELECT CAST(postal_code AS text) ~ '[0-9]{5}'
FROM customer;
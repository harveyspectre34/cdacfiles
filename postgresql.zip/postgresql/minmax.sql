select * from custdata1;
select avg(age) as "Average customer age" from custdata1;
select count(gender) as "no of females"  from custdata1 where age between 20 and 30 and  gender='Female';
select avg(price::numeric*.10) as "Average Commision Value" from custdata1;

select min(price) as "Minimum Sales Value" from custdata1 where invoice_date between '2021-06-01' and '2023-06-30';

select price
from custdata1
where invoice_date between '2021-06-01' and '2023-06-30'
order by price asc;

select max(price) as "Maximum Sales Value" from custdata1 where invoice_date between '2021-06-01' and '2023-06-30';

select price
from custdata1
where invoice_date between '2021-06-01' and '2023-06-30'
order by price desc;
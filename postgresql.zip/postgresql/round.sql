select order_line,sales,round(sales) from sales order by sales
select * from sales;

select power(6,2);
select age,power(age,2) from customer order by age;
select customer_id, random() as rand_n from customer order by rand_n limit 5;

select order_line,sales,ceil(sales) from sales order by sales;

select sum(ceil(sales)) as total_sales from sales;

select order_line,sales,ceil(sales),SUM(ceil(sales)) as total_sales from sales order by sales;

SELECT SUM(CEILING(sales)) AS total_sales_revenue
FROM sales;

SELECT SUM(FLOOR(sales)) AS total_sales_revenue
FROM sales;

select current_date;

select current_time;

select current_time(1),current_time(3);

select current_timestamp;

select age('2014-04-25','2014-01-01');

select age(current_date,'1939-04-01');

select order_line,order_date,ship_date,age(ship_date,order_date) as time_taken
from sales
order by time_taken desc;
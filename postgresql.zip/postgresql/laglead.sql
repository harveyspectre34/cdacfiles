select * from sales;
create table order_rollup as (select order_id,max(order_date) as order_date,max(customer_id) as customer_id,sum(sales) as sales from sales group by order_id);
create table order_rollup_state as select a.*,b.state
from order_rollup as a
left join customer as b
on a.customer_id=b.customer_id;

select * from order_rollup;
select * from order_rollup_state;
select * from customer;

SELECT SUM(sales) AS total_sales
FROM order_rollup_state as a
JOIN customer as b 
ON a.customer_id = b.customer_id  -- Assuming 'id' is the common column
WHERE b.customer_name = 'Evan Henry' AND a.state = 'Alabama';

SELECT COUNT(*) AS customer_count
FROM customer
WHERE state = 'Connecticut';

select *,
sum(sales) over (partition by state) as sales_state_total,
sum(sales) over (partition by state order by order_date) as running_total
from order_rollup_state;

select customer_id,order_date,order_id,sales,
lag(sales,1) over (partition by customer_id order by order_date) as previous_sales,
lag(order_id,1) over (partition by customer_id order by order_date) as previous_order_id
from order_rollup_state;

select customer_id,order_date,order_id,sales,
lead(sales,1) over (partition by customer_id order by order_date) as previous_sales,
lead(order_id,1) over (partition by customer_id order by order_date) as previous_order_id
from order_rollup_state;

select running_total,state,
sum(sales) over (partition by state) as sales_state_total,
sum(sales) over (partition by state order by order_date) as running_tota
where state ="California"
from order_rollup_state;

select extract(day from current_date);
select extract(day from '2014-04-25');
select current_timestamp,extract(hour from current_timestamp);

select extract(day from '1997-01-14');

select * from sales;



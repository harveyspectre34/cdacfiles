
CREATE TABLE zip_codes (
    code VARCHAR(10)
);
insert into zip_codes values (234432);
insert into zip_codes values (23345);
INSERT INTO zip_codes (code) VALUES ('sdfe4');
insert into zip_codes values ('sdfe4');
insert into zip_codes values ('123&3');
insert into zip_codes values (67424);
insert into zip_codes values (7895432);
insert into zip_codes values (12312);

select * from zip_codes;

DELETE FROM zip_codes
WHERE code = '3';

SELECT *
FROM zip_codes
WHERE code ~ '^[0-9]{5}$';


23345
sdfe4
123&3
67424
7895432
12312

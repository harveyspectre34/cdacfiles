create table sales_2015 as select * from sales where ship_date between '2015-01-01' and '2015-12-31';
select count(*) from sales_2015; 
select count(distinct customer_id) from sales_2015;

select * from sales_2015;
select * from customer_20_60;

SELECT *
FROM sales_2015
WHERE product_id like 'FUR-BO%';

SELECT SUM(sales) AS total_sales
FROM sales_2015
WHERE product_id = 'FUR-BO-10000112';
ORDER BY product_id; 

select
a.sales,
a.product_id,
b.customer_id,
b.state
from sales_2015 as a
inner join customer_20_60 as b
on a.customer_id = b.customer_id
order by customer_id;
select sum(sales) where state = 'Florida';

SELECT SUM(sales) AS total_sales
FROM sales_2015
INNER JOIN customer_20_60 ON sales_2015.customer_id = customer_20_60.customer_id
WHERE state = 'Florida';


create table customer_20_60 as select * from customer where age between 20 and 60;
select count (*) from customer_20_60;

select
a.order_line,
a.product_id,
a.customer_id,
a.sales,
b.customer_name,
b.age
from sales_2015 as a
inner join customer_20_60 as b
on a.customer_id = b.customer_id
order by customer_id;


select customer_id from sales_2015 order by customer_id; 
select customer_id from customer_20_60 order by customer_id;

select
a.order_line,
a.product_id,
b.customer_id,
a.sales,
b.customer_name,
b.age
from sales_2015 as a
right join customer_20_60 as b
on a.customer_id = b.customer_id
order by customer_id;


select
a.order_line,
a.product_id,
a.customer_id,
a.sales,
b.customer_name,
b.age,
b.customer_id
from sales_2015 as a
full join customer_20_60 as b
on a.customer_id = b.customer_id
order by a.customer_id,b.customer_id;

/* cross join */
 create table month_values (MM integer);
 create table year_values (YYYY integer);

 insert into month_values values (1),(2),(3),(4),(5),(6),(7),(8),(9),(10),(11),(12);
 insert into year_values values (2011),(2012),(2013),(2014),(2015),(2016),(2017),(2018),(2019);

 select * from month_values;
 select * from year_values;

 select a.YYYY,b.MM
 from year_values as a,month_values as b
 order by a.YYYY,b.MM;

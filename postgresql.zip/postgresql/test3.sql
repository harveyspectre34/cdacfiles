select * from customer_table;

alter table customer_table add test varchar(255);

alter table customer_table drop test;
alter table customer_table drop column test;
alter table customer_table alter column age type varchar(255);
alter table customer_table rename column email_id to customer_email;
alter table customer_table alter column cust_id set not null;

insert into customer_table(first_name,last_name,age,customer_email) values ('aa','bb','23','ab@xyz.com');
 alter table customer_table alter column cust_id drop not null;
 
 alter table customer_table add constraint cust_id check(cust_id >0);
 
 insert into customer_table values(-1,'cc','dd','25','cd@xyz.com');

 alter table customer_table add primary key(cust_id);
 delete from customer_table;
  insert into customer_table values(1,'cc','dd','25','cd@xyz.com');
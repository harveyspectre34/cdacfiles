select first_name from customer_table;
select distinct  first_name from customer_table;
select distinct first_name from customer_table where age >25;
select * from customer_table where first_name = 'gee';
select first_name,last_name, age from customer_table where age <20 or age>= 30;
select * from customer_table where not age =25;
insert into customer_table values (1,'Rohan',25.rk@xyz.com);

